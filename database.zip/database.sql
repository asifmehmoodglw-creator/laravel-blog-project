-- MySQL dump 10.13  Distrib 8.4.3, for Win64 (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Sports','sports','2026-08-21 17:01:36','2026-08-21 17:01:36'),(10,'Contructions','contructions','2026-08-21 18:26:21','2026-08-21 18:26:21'),(11,'Chinagate','chinagate','2026-08-21 19:56:22','2026-08-24 18:56:54'),(13,'Software Industry','software industry','2026-08-24 19:48:41','2026-08-24 19:48:41'),(14,'Islamic','islamic','2026-08-25 12:12:06','2026-08-25 12:12:06'),(15,'War','war','2026-08-25 17:42:37','2026-08-25 17:42:37'),(16,'Oppressed','oppressed','2026-08-25 19:10:20','2026-08-25 19:10:20'),(17,'Cricket','cricket','2026-09-03 13:35:46','2026-09-03 13:35:46'),(18,'Entertainment','entertainment','2026-09-03 13:53:38','2026-09-03 13:53:38'),(19,'Bollywood','bollywood','2026-09-03 14:33:03','2026-09-03 14:33:03'),(20,'Hollywood','hollywood','2026-09-03 14:37:36','2026-09-03 14:37:36'),(33,'Business','business','2026-09-03 14:41:33','2026-09-03 14:41:33'),(35,'Business1','business1','2026-09-03 14:41:58','2026-09-03 14:41:58'),(36,'Food','food','2026-09-03 14:43:06','2026-09-03 14:43:06'),(37,'Computer','computer','2026-09-03 14:45:02','2026-09-03 14:45:02'),(38,'East','east','2026-09-03 15:00:54','2026-09-03 15:00:54'),(39,'Gold','gold','2026-09-03 16:10:52','2026-09-03 16:10:52'),(40,'Nuclear weapon','nuclear weapons','2026-09-03 16:12:13','2026-09-03 16:12:13'),(41,'Subcontinent','subcontinent','2026-09-03 16:13:07','2026-09-03 16:13:07'),(42,'Holland','holland','2026-09-03 18:31:30','2026-09-03 18:31:30'),(43,'Holland1','holland1','2026-09-03 18:41:24','2026-09-03 18:41:24'),(44,'WorldWide','worldwide','2026-09-03 18:42:28','2026-09-03 18:42:28'),(45,'y','y','2026-09-03 18:42:55','2026-09-03 18:42:55'),(46,'b','b','2026-09-03 18:43:47','2026-09-03 18:43:47'),(47,'Night','night','2026-09-03 18:46:42','2026-09-03 18:46:42');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_post_id_foreign` (`post_id`),
  KEY `comments_user_id_foreign` (`user_id`),
  CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (2,13,3,'Fantastic','2026-08-31 17:01:38','2026-08-31 17:01:38'),(3,11,3,'better','2026-08-31 17:34:54','2026-08-31 17:34:54'),(5,13,3,'micheal jackson was a best dancer in whole world','2026-08-31 18:27:09','2026-08-31 18:27:09'),(6,13,3,'wol','2026-08-31 18:27:52','2026-08-31 18:27:52'),(7,13,2,'wow! it\'s amazing','2026-08-31 18:29:25','2026-08-31 18:29:25'),(8,13,2,'test comment','2026-08-31 18:44:55','2026-08-31 18:44:55'),(9,13,3,'kmkmk','2026-09-01 18:06:45','2026-09-01 18:06:45'),(10,11,3,'they became fixtures in the latter stages of tournaments. They won their first international trophy, the ICC World Cup, in 1992, and then won the Asia Cup in 2000. They saw increased success in the 21st century, winning the T20 World Cup in 2009, the Asia Cup in 2012, and ICC Champions Trophy in 2017','2026-09-01 18:37:16','2026-09-01 18:37:16'),(11,11,3,'kjkk','2026-09-01 18:37:56','2026-09-01 18:37:56'),(12,11,3,'kokkokop','2026-09-01 18:38:09','2026-09-01 18:38:09'),(13,13,3,'it is reality','2026-09-02 13:11:29','2026-09-02 13:11:29'),(14,13,3,'it is reality','2026-09-02 13:11:35','2026-09-02 13:11:35'),(15,13,3,'it is reality','2026-09-02 13:11:41','2026-09-02 13:11:41'),(16,13,3,'it is reality','2026-09-02 13:11:43','2026-09-02 13:11:43'),(17,13,3,'it is reality','2026-09-02 13:11:46','2026-09-02 13:11:46'),(18,13,3,'it is reality','2026-09-02 13:11:48','2026-09-02 13:11:48'),(19,13,3,'it is reality','2026-09-02 13:11:51','2026-09-02 13:11:51'),(20,13,3,'it is reality','2026-09-02 13:11:55','2026-09-02 13:11:55'),(21,13,3,'it is reality','2026-09-02 13:11:58','2026-09-02 13:11:58'),(22,13,3,'it is reality','2026-09-02 13:12:01','2026-09-02 13:12:01'),(23,13,3,'it is reality','2026-09-02 13:12:05','2026-09-02 13:12:05'),(24,13,3,'it is reality','2026-09-02 13:12:12','2026-09-02 13:12:12'),(25,13,3,'it is reality','2026-09-02 13:12:15','2026-09-02 13:12:15'),(26,13,3,'it is reality','2026-09-02 13:12:18','2026-09-02 13:12:18'),(27,13,3,'it is reality','2026-09-02 13:12:21','2026-09-02 13:12:21'),(28,13,3,'it is reality','2026-09-02 13:12:23','2026-09-02 13:12:23'),(29,13,3,'it is reality','2026-09-02 13:12:26','2026-09-02 13:12:26'),(30,13,3,'it is reality','2026-09-02 13:12:29','2026-09-02 13:12:29'),(31,13,3,'acha','2026-09-02 13:13:39','2026-09-02 13:13:39'),(32,13,3,'acha','2026-09-02 13:14:09','2026-09-02 13:14:09'),(33,13,3,'acha','2026-09-02 13:14:11','2026-09-02 13:14:11'),(34,13,3,'acha','2026-09-02 13:15:11','2026-09-02 13:15:11'),(35,13,3,'acha','2026-09-02 13:15:16','2026-09-02 13:15:16'),(36,13,3,'acha','2026-09-02 13:15:19','2026-09-02 13:15:19'),(37,13,3,'acha','2026-09-02 13:15:22','2026-09-02 13:15:22'),(38,13,3,'dsssda','2026-09-02 13:16:10','2026-09-02 13:16:10'),(39,13,3,'dsssda','2026-09-02 13:16:15','2026-09-02 13:16:15'),(40,13,3,'retregd','2026-09-02 13:19:19','2026-09-02 13:19:19'),(41,13,3,'retregd','2026-09-02 13:19:27','2026-09-02 13:19:27'),(42,13,3,'retregd','2026-09-02 13:19:29','2026-09-02 13:19:29'),(43,13,3,'retregd','2026-09-02 13:19:31','2026-09-02 13:19:31'),(44,13,3,'retregd','2026-09-02 13:19:33','2026-09-02 13:19:33'),(45,13,3,'fddgrr','2026-09-02 13:25:43','2026-09-02 13:25:43'),(46,13,3,'fddgrr','2026-09-02 13:25:47','2026-09-02 13:25:47'),(47,13,3,'fddgrr','2026-09-02 13:25:50','2026-09-02 13:25:50'),(48,13,3,'erfer','2026-09-02 13:26:01','2026-09-02 13:26:01'),(49,13,3,'fvfvf','2026-09-02 13:40:07','2026-09-02 13:40:07'),(50,13,3,'fvfvf','2026-09-02 13:40:14','2026-09-02 13:40:14'),(51,13,3,'fvdvd','2026-09-02 13:51:42','2026-09-02 13:51:42'),(52,13,3,'fvdvd','2026-09-02 13:51:45','2026-09-02 13:51:45'),(53,13,3,'retreytrtrfdsf','2026-09-02 13:52:46','2026-09-02 13:52:46'),(54,13,3,'retreytrtrfdsf','2026-09-02 13:52:48','2026-09-02 13:52:48'),(55,13,3,'dsfdfsada','2026-09-02 13:58:52','2026-09-02 13:58:52'),(56,13,3,'dsfdfsada','2026-09-02 13:59:14','2026-09-02 13:59:14'),(57,13,3,'dsfdfsada','2026-09-02 14:00:19','2026-09-02 14:00:19'),(58,13,3,'dsfdfsada','2026-09-02 14:00:21','2026-09-02 14:00:21'),(59,13,3,'dsfdfsada','2026-09-02 14:00:23','2026-09-02 14:00:23'),(60,13,3,'dsfdfsada','2026-09-02 14:00:25','2026-09-02 14:00:25'),(61,13,3,'dsfdfsada','2026-09-02 14:00:27','2026-09-02 14:00:27'),(62,13,3,'dsfdfsada','2026-09-02 14:00:30','2026-09-02 14:00:30'),(63,13,3,'dsfdfsada','2026-09-02 14:00:32','2026-09-02 14:00:32'),(64,13,3,'dsfdfsada','2026-09-02 14:00:34','2026-09-02 14:00:34'),(65,13,3,'dsfdfsada','2026-09-02 14:00:36','2026-09-02 14:00:36'),(66,13,3,'dsfdfsada','2026-09-02 14:00:37','2026-09-02 14:00:37'),(67,13,3,'dsfdfsada','2026-09-02 14:00:40','2026-09-02 14:00:40'),(68,13,3,'dsfdfsada','2026-09-02 14:00:42','2026-09-02 14:00:42'),(69,13,3,'dsfdfsada','2026-09-02 14:00:45','2026-09-02 14:00:45'),(70,13,3,'dsfdfsada','2026-09-02 14:19:53','2026-09-02 14:19:53'),(71,13,3,'dsfdfsada','2026-09-02 14:19:56','2026-09-02 14:19:56'),(72,13,3,'dsfd','2026-09-02 14:20:29','2026-09-02 14:20:29'),(73,13,3,'dsfd','2026-09-02 14:20:31','2026-09-02 14:20:31'),(74,13,3,'dsfd','2026-09-02 14:20:34','2026-09-02 14:20:34'),(75,13,3,'vcxcxcxzx','2026-09-02 14:20:53','2026-09-02 14:20:53'),(76,13,3,'vcxcxcxzx','2026-09-02 14:20:55','2026-09-02 14:20:55'),(77,13,3,'vcxcxcxzx','2026-09-02 14:40:50','2026-09-02 14:40:50'),(78,13,3,'vcxcxcxzx','2026-09-02 14:40:52','2026-09-02 14:40:52'),(79,13,3,'vcxcxcxzx','2026-09-02 14:41:34','2026-09-02 14:41:34'),(80,13,3,'uyutyr','2026-09-02 14:41:52','2026-09-02 14:41:52'),(81,13,3,'dfqwwqvb','2026-09-02 14:48:12','2026-09-02 14:48:12'),(82,13,3,'dfqwwqvb','2026-09-02 14:48:15','2026-09-02 14:48:15'),(83,13,3,'dfqwwqvb','2026-09-02 14:48:19','2026-09-02 14:48:19'),(84,13,3,'good','2026-09-02 16:34:58','2026-09-02 16:34:58'),(85,13,3,'good','2026-09-02 16:35:00','2026-09-02 16:35:00'),(86,13,3,'good','2026-09-02 16:35:08','2026-09-02 16:35:08'),(87,13,3,'good','2026-09-02 16:35:09','2026-09-02 16:35:09'),(88,13,3,'best','2026-09-02 16:42:39','2026-09-02 16:42:39'),(89,13,3,'knk','2026-09-02 16:46:49','2026-09-02 16:46:49'),(90,13,3,'mklmkl','2026-09-02 16:49:24','2026-09-02 16:49:24'),(91,13,3,'kjhkhlkhl','2026-09-02 17:04:09','2026-09-02 17:04:09'),(92,13,3,'kpokpokpkop','2026-09-02 17:06:10','2026-09-02 17:06:10'),(93,13,3,'fdfdffsac','2026-09-02 17:17:46','2026-09-02 17:17:46'),(94,13,3,'ewrfewe','2026-09-02 17:18:00','2026-09-02 17:18:00'),(95,13,3,'fefecd','2026-09-02 17:18:09','2026-09-02 17:18:09'),(96,13,3,'asif','2026-09-02 17:18:27','2026-09-02 17:18:27'),(97,13,3,'mehmood','2026-09-02 17:21:49','2026-09-02 17:21:49'),(98,13,3,'ffdsfdfsdwewdcxzvczxcvdsfedsa','2026-09-02 17:22:04','2026-09-02 17:22:04'),(99,13,3,'Raja king','2026-09-02 17:31:27','2026-09-02 17:31:27'),(100,13,3,'rrfrf','2026-09-02 19:36:02','2026-09-02 19:36:02'),(101,13,3,'How is it possible','2026-09-02 19:36:24','2026-09-02 19:36:24'),(102,13,3,'Rana','2026-09-02 19:42:22','2026-09-02 19:42:22'),(103,13,3,'Hello World','2026-09-02 19:42:37','2026-09-02 19:42:37'),(104,13,2,'Amazing','2026-09-02 19:48:52','2026-09-02 19:48:52'),(105,13,2,'salam','2026-09-02 19:51:52','2026-09-02 19:51:52'),(106,13,3,'gulzar','2026-09-03 12:13:22','2026-09-03 12:13:22'),(107,13,3,'gulzar','2026-09-03 12:13:25','2026-09-03 12:13:25'),(108,12,3,'good','2026-09-03 12:47:38','2026-09-03 12:47:38'),(109,12,3,'good','2026-09-03 12:47:40','2026-09-03 12:47:40'),(110,9,3,'Good','2026-09-03 14:59:43','2026-09-03 14:59:43'),(111,11,1,'tuyty','2026-09-03 19:38:09','2026-09-03 19:38:09');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2021_04_08_180818_create_posts_table',1),(5,'2021_04_16_154312_create_categories_table',1),(6,'2021_06_18_143226_create_comments_table',1),(7,'2026_08_13_052939_add_thumbnail_to_posts_table',2),(8,'2026_08_20_100317_add_is_admin_to_users_table',2),(9,'2026_08_27_073735_create_ratings_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_user_id_foreign` (`user_id`),
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (8,3,'Iran vs america, War 2026','15','thumbnails/E1wG2SIyqCRKZFGtz7mWwEjDs1soVyAFiKG6dNXR.webp','The war is part of a Middle Eastern crisis sparked by the Gaza war. It follows the Twelve-Day War and was preceded by the largest US military buildup in the region since the 2003 invasion of Iraq. US justifications for initiating the war included a response to the crackdown on anti-government protests in Iran, preventing Iran from obtaining a nuclear weapon, regime change, and taking Iran\'s oil and gas resources. Critics have rejected these justifications, maintaining that the attack initiated a war of aggression, in violation of international law.','Since 28 February 2026, the United States and Israel have been at war with Iran and its regional allies. Hostilities broke out after US–Israeli airstrikes killed several Iranian officials, including Supreme Leader Ali Khamenei. The strikes were launched amid ongoing US–Iran negotiations regarding Iran\'s nuclear program.','2026-08-25 17:45:56','2026-08-25 17:45:56',NULL),(9,3,'DR Israr Prediction, Pakistan Vs Israil','14','thumbnails/dXr7aZJ8LFhrEup0WINlQRPqYDOoWBizUG6GyXqb.webp','AI Overview\r\n\r\nLike\r\n\r\nDislike\r\nDr. Israr Ahmad’s predictions focus on Islamic prophecies, global events, and the future role of Muslim nations, emphasizing unity, ethical guidance, and spiritual preparedness.\r\nOverview of Predictions\r\nDr. Israr Ahmad, a renowned Islamic scholar, interpreted Prophet Muhammad ﷺ’s prophecies to provide insights into future events, particularly concerning the Muslim world and global geopolitics. His predictions often highlight:\r\nGeopolitical Shifts: He foresaw the emergence of a stronger Islamic bloc including countries like Iran, Pakistan, Afghanistan, and Central Asian states, reflecting prophetic guidance about unity in the Ummah (Muslim community) and potential global influence in 2026 (YouTube lecture, Drisrar)','Global Conflicts: Dr. Israr discussed tensions involving nations such as Iran, Israel, the UAE, Saudi Arabia, the USA, China, and Pakistan, emphasizing the importance of understanding historical and political changes in light of Islamic teachings \r\nkhuddamulquran.org\r\nkhuddamulquran.org.\r\nMoral and Spiritual Guidance: His predictions stress the resurgence of true Islamic values, urging Muslims to adhere to Quranic principles, maintain strong faith, and avoid straying from the teachings of Hadith \r\nSigns and Warnings: He outlined recurrent signs that precede significant prophetic events, helping believers recognize spiritual and worldly developments that align with Islamic eschatology','2026-08-25 17:55:12','2026-08-25 17:55:12',NULL),(10,3,'Mansa Musa, Empire of Mali','14','thumbnails/CVXM8HkWudZsjENV3daEPeTgr23is7FXzgdMr8cK.jpg','Mansa Musa, also known as Musa I of Mali, was the ninth mansa (emperor) of the Mali Empire from c.1312 to 1337, leading it to its peak in wealth, territory, and prestige. Controlling vast gold and salt resources and key trans-Saharan trade routes, he is often regarded as the wealthiest person in history. His 1324 pilgrimage to Mecca, accompanied by a lavish caravan of thousands and massive quantities of gold, astonished Cairo and caused regional gold prices to drop for years. Musa expanded the empire, incorporating Timbuktu and Gao, and commissioned monumental mosques and learning centers like the Djinguereber Mosque, turning Timbuktu into a major hub of Islamic scholarship and trade.','Mansa Musa, also known as Musa I of Mali or Kanku Musa, became emperor around 1312 after the disappearance of his predecessor, Mansa Abu Bakr II, who embarked on an Atlantic expedition and never returned. He was either the grandson or grandnephew of Sundiata Keita, the founder of the Mali Empire. His reign marked the peak of Mali’s territorial and economic power, encompassing modern-day Mali, Senegal, Mauritania, the Gambia, Guinea, Niger, Nigeria, Chad, and Burkina Faso','2026-08-25 17:59:25','2026-08-25 17:59:25',NULL),(11,3,'Pak vs Eng, ODI','1','thumbnails/PG8FvnoKWEZ9YE8qj1Z2vwDQJS8cpdPfNHm5s3yn.webp','The Pakistan men\'s national cricket team represents Pakistan in international cricket. It is controlled by the Pakistan Cricket Board (PCB), the governing body for cricket in Pakistan, which is a Full Member of the International Cricket Council (ICC). Pakistan compete in cricket tours and tournaments sanctioned by the PCB and other regional or international cricket bodies in Test, One Day International (ODI), and Twenty20 International (T20) formats.','Pakistan were given Test status in 1952 following a recommendation from India, but faced limited international success until the 1980s, when they became fixtures in the latter stages of tournaments. They won their first international trophy, the ICC World Cup, in 1992, and then won the Asia Cup in 2000. They saw increased success in the 21st century, winning the T20 World Cup in 2009, the Asia Cup in 2012, and ICC Champions Trophy in 2017','2026-08-25 19:03:16','2026-08-25 19:03:16',NULL),(12,3,'Palestinian People,','16','thumbnails/la5BjEu6WlpxgS4qKFp1fiiY4RQx8lOoYrRsScFt.jpg','Palestine,[i][g] officially the State of Palestine,[ii] is a country in the Southern Levant region of West Asia. It encompasses the West Bank, including East Jerusalem, and the Gaza Strip, both of which are occupied by Israel. These territories are collectively known as the Palestinian territories, or occupied Palestinian territory. They share the vast majority of their borders with Israel, with the West Bank bordering Jordan to the east and the Gaza Strip bordering Egypt to the southwest. It has a total land area of 6,020 square kilometers (2,320 sq mi) while its population exceeds five million. Its proclaimed capital is Jerusalem, while Ramallah serves as its de facto administrative center. Gaza was its largest city prior to Israel\'s forced evacuations in 2023,[2][3] following Hamas\'s October 7 attacks.','The 1948 Palestine war saw the forcible displacement of a majority of the Arab population, and consequently the establishment of Israel; these events are referred to by Palestinians as the Nakba (\'catastrophe\'). In the Six-Day War in 1967, Israel occupied the West Bank and the Gaza Strip, which had been held by Jordan and Egypt respectively. The Palestine Liberation Organization (PLO) declared independence in 1988. In 1993, the PLO signed the Oslo Accords with Israel, creating limited PLO governance in the West Bank and Gaza Strip through the Palestinian Authority (PA).','2026-08-25 19:14:04','2026-08-25 19:14:04',NULL),(13,2,'Micheal Jackson','1','thumbnails/9gBG1Yd5q5aFLx3R3J5S5nzcYjXxcmDnm1pzaPGI.webp','Michael Joseph Jackson (August 29, 1958 – June 25, 2009) was an American singer, songwriter, dancer, and philanthropist. Dubbed the \"King of Pop\", he is widely regarded as one of the most culturally significant figures of the 20th century. His musical achievements broke American racial barriers and made him a dominant figure worldwide. Through his songs, music videos, concerts, and fashion, he transformed visual performance in popular music, popularizing street dance moves such as the moonwalk, the robot, and the anti-gravity lean. Jackson is often deemed the greatest entertainer of all time','Huitième d\'une famille de dix enfants (dont un meurt à la naissance : le jumeau de Marlon), il chante avec ses frères dès l\'âge de six ans et commence une carrière professionnelle à onze ans au sein des Jackson Five, groupe formé avec ses frères aînés. Tout en restant membre du groupe (jusqu\'en 1984), il entame en 1971 une carrière solo. Cinq de ses albums solo parus de son vivant figurent parmi les albums les plus vendus au monde : Off the Wall (1979), Thriller (1982), Bad (1987), Dangerous (1991) et HIStory (1995).','2026-08-27 19:09:53','2026-08-27 19:09:53',NULL),(37,2,'AI Automation','13','thumbnails/eGWNFVgxU6pyJ4zNL2ptcNyJXGTHNRpEcHAfafHx.webp','Automation refers to using technology to perform repetitive, rule-based tasks without human intervention. It follows predefined instructions and is ideal for predictable processes like manufacturing assembly lines, robotic process automation (RPA) for form-filling, or automated email responses . It does not adapt to new situations — if the input changes unexpectedly, automation may fail.','Artificial Intelligence (AI), on the other hand, enables machines to perform complex, decision-making tasks that traditionally require human intelligence. AI systems can learn from data, adapt to new inputs, and improve over time. Technologies like machine learning, natural language processing (NLP), computer vision, and predictive analytics allow AI to handle unstructured data, make predictions, and respond dynamically .','2026-09-03 19:02:44','2026-09-03 19:02:44',NULL),(38,2,'Textile Engineer','13','thumbnails/DFaK48ZLFy8GSS8fMAjRRotLW0J4KW2182xeKovh.webp','Textile engineering is a dynamic field that combines science, technology, and creativity to produce high-quality fabrics used in various industries. Textile engineers are essential in designing, testing, and refining every stage of textile production, ensuring products are durable, comfortable, and fit for their intended use. They work in diverse sectors, including fashion, home textiles, medical textiles, and automotive interiors','The field is also focused on sustainability and innovation, with smart fabrics and eco-friendly materials becoming increasingly important. Textile engineers play a crucial role in the fabric industry, turning raw materials into usable, high-quality fabrics and ensuring products meet the needs of consumers and industries alike. \r\nNED University of Engineering & Technology','2026-09-03 19:07:29','2026-09-03 19:07:29',NULL),(39,1,'Cristiano Ronaldo','1','thumbnails/co0vZvUuf13RHI4bRfmebn7xuZF7gw9bxl9EA7fF.webp','Cristiano Ronaldo dos Santos Aveiro[a] (born 5 February 1985) is a Portuguese professional footballer who plays as a forward for and captains the Saudi Pro League club Al-Nassr and the Portugal national team. Nicknamed CR7, he is widely regarded as one of the greatest players in history, having won numerous individual accolades throughout his career including five Ballon d\'Or awards, a record three UEFA Men\'s Player of the Year Awards, and four European Golden Shoes. He was named the world\'s best player five times by FIFA','Ronaldo is one of the most decorated players in the history of professional football, having won 35 trophies in his career, including five UEFA Champions Leagues, two UEFA Nations Leagues and the UEFA European Championship. He holds the records for most goals (140) and assists (42) in the Champions League, most goals (14) and assists (8) in the European Championship, most international appearances (233), most men\'s international goals (146),','2026-09-03 19:13:44','2026-09-03 19:46:06',NULL);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ratings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `card_id` bigint unsigned NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings`
--

LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
INSERT INTO `ratings` VALUES (1,1,'127.0.0.1','5','2026-08-27 16:57:16','2026-08-27 17:51:03'),(2,1,'4','4','2026-08-27 18:45:35','2026-08-27 18:45:35'),(3,1,'2','4','2026-08-27 18:52:52','2026-08-27 18:55:03'),(4,1,'3','2','2026-08-28 12:55:19','2026-08-28 13:42:08'),(5,3,'127.0.0.1','5','2026-08-28 16:55:03','2026-08-28 16:55:03'),(6,11,'127.0.0.1','4','2026-08-28 17:16:06','2026-08-28 17:16:06'),(7,13,'4','1','2026-08-28 17:18:07','2026-08-28 17:18:07'),(8,8,'3','4','2026-08-28 17:20:03','2026-08-28 17:20:03'),(9,13,'3','3','2026-09-01 18:39:19','2026-09-01 19:04:01');
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'koha','koha','koha@gmail.com',0,NULL,'$2y$10$felD3dJTSG4GxpASiv32HOdiMbSAilAfxVPH.vkqhFFU6Sy2WQfV6',NULL,'2026-08-20 14:58:21','2026-08-20 14:58:21'),(2,'ali','Ali','ali@gmail.com',0,NULL,'$2y$10$cbi5VfBCen6Xc1ZxDmnDyOcm1yN00d79wtaCT2DxGYxP95g4cp1KG',NULL,'2026-08-20 16:32:04','2026-08-20 16:32:04'),(3,'admin','Admin','admin@gmail.com',1,NULL,'$2y$10$VjNkDnHNE/EhMfcYHdDAKu4j3L6q0sqGKaoA5kbTZEw8AHcouYrMy',NULL,'2026-08-20 17:12:21','2026-08-20 17:33:59'),(4,'ghuman','Ghuman','ghuman@gmail.com',0,NULL,'$2y$10$N3an./wj2lyOMsJo968BRu4x1fmbzkSZk6T.GGLXWE/1uWf6yT96O',NULL,'2026-08-27 18:40:54','2026-08-27 18:40:54');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03 22:13:59
